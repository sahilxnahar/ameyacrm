import 'server-only';
import { prisma } from '@/lib/db/prisma';
import { env } from '@/config/env';
import { embed, cosine, chunkText } from '@/lib/ai/embeddings';
import { can } from '@/lib/rbac/can';
import { ALL_PERMISSION_KEYS } from '@/lib/rbac/permissions';
import { lockedFolderIds } from '@/server/services/folder-access-service';
import type { AuthContext } from '@/types/auth';

export interface Source { title: string; snippet: string; documentId: string | null; fileObjectId: string | null; score: number }
export interface Answer { answer: string; sources: Source[]; searched: number }

/** Index one document's text. Replaces any previous chunks for it. */
export async function indexText(opts: {
  documentId?: string | null;
  fileObjectId?: string | null;
  title: string;
  source?: string | null;
  text: string;
  folderId?: string | null;
  requiredPermission?: string | null;
  entityType?: string | null;
  entityId?: string | null;
}): Promise<number> {
  const chunks = chunkText(opts.text);
  if (!chunks.length) return 0;

  const scope = opts.documentId
    ? { documentId: opts.documentId }
    : opts.fileObjectId
      ? { fileObjectId: opts.fileObjectId }
      : opts.entityType && opts.entityId
        ? { entityType: opts.entityType, entityId: opts.entityId }
        : null;
  if (scope) await prisma.docChunk.deleteMany({ where: scope });

  let stored = 0;
  for (let i = 0; i < Math.min(chunks.length, 60); i++) {
    const piece = chunks[i];
    if (!piece) continue;
    const vec = await embed(piece);
    if (!vec) continue;
    await prisma.docChunk.create({
      data: {
        documentId: opts.documentId ?? null,
        fileObjectId: opts.fileObjectId ?? null,
        title: opts.title.slice(0, 200),
        source: opts.source ?? null,
        folderId: opts.folderId ?? null,
        requiredPermission: opts.requiredPermission ?? null,
        entityType: opts.entityType ?? null,
        entityId: opts.entityId ?? null,
        ordinal: i,
        content: piece,
        embedding: vec,
        tokens: Math.round(piece.length / 4),
      },
    });
    stored++;
    await new Promise((r) => setTimeout(r, 120));
  }
  return stored;
}

/**
 * Answer from the indexed documents only. If nothing relevant is found the
 * answer says so — a confident invention about a penalty clause would be worse
 * than no answer at all.
 */
export async function askDocuments(question: string, ctx: AuthContext): Promise<Answer> {
  const q = question.trim();
  if (!q) return { answer: 'Ask a question about your documents.', sources: [], searched: 0 };

  const qvec = await embed(q, 'query');

  // Everything is indexed, but each person is answered only from what they
  // could open themselves. Two filters, applied in the query rather than after
  // ranking so a restricted passage never even reaches the model.
  const locked = await lockedFolderIds(ctx);
  const permissionFilter = {
    OR: [
      { requiredPermission: null },
      { requiredPermission: { in: ALL_PERMISSION_KEYS.filter((k) => can(ctx.permissions, k)) } },
    ],
  };
  const allowed = locked.length
    ? { AND: [permissionFilter, { OR: [{ folderId: null }, { folderId: { notIn: locked } }] }] }
    : permissionFilter;

  // Narrow before scoring. Loading every embedding meant pulling roughly 25MB
  // into memory for a single question; a keyword pass first cuts the candidate
  // set to something small, and only then do we do the expensive maths.
  const words = [...new Set(q.toLowerCase().split(/\W+/).filter((w) => w.length > 3))].slice(0, 8);
  let chunks = words.length
    ? await prisma.docChunk.findMany({
        where: { AND: [allowed, { OR: words.map((w) => ({ content: { contains: w, mode: 'insensitive' as const } })) }] },
        select: { id: true, title: true, content: true, documentId: true, fileObjectId: true, embedding: true, source: true },
        take: 400,
      })
    : [];

  // Nothing matched on words alone — fall back to a bounded scan so an
  // unusually phrased question still finds something.
  if (chunks.length < 5) {
    chunks = await prisma.docChunk.findMany({
      where: allowed,
      select: { id: true, title: true, content: true, documentId: true, fileObjectId: true, embedding: true, source: true },
      orderBy: { createdAt: 'desc' },
      take: 600,
    });
  }
  if (!chunks.length) {
    return {
      answer: 'There is nothing indexed that you have access to. If you expected results here, ask a Super Admin to run Admin > AI Health > Index everything.',
      sources: [], searched: 0,
    };
  }

  let ranked: Array<{ c: (typeof chunks)[number]; score: number }>;
  if (qvec) {
    ranked = chunks.map((c) => ({ c, score: cosine(qvec, c.embedding) })).sort((a, b) => b.score - a.score);
  } else {
    // No AI key — fall back to plain keyword overlap so the feature still works.
    const words = q.toLowerCase().split(/\W+/).filter((w) => w.length > 3);
    ranked = chunks
      .map((c) => ({ c, score: words.filter((w) => c.content.toLowerCase().includes(w)).length / Math.max(1, words.length) }))
      .sort((a, b) => b.score - a.score);
  }

  const top = ranked.filter((r) => r.score > 0.25).slice(0, 6);
  if (!top.length) {
    return { answer: 'I could not find anything about that in the documents that have been indexed.', sources: [], searched: chunks.length };
  }

  const context = top.map((r, i) => `[${i + 1}] ${r.c.title}\n${r.c.content}`).join('\n\n---\n\n');
  const answer = await generate(q, context);

  return {
    answer,
    sources: top.map((r) => ({
      title: r.c.title,
      snippet: r.c.content.slice(0, 260),
      documentId: r.c.documentId,
      fileObjectId: r.c.fileObjectId,
      score: Math.round(r.score * 100),
    })),
    searched: chunks.length,
  };
}

async function generate(question: string, context: string): Promise<string> {
  const { aiChat } = await import('@/lib/ai/provider');
  const r = await aiChat({
    system:
      'You answer questions about an Indian real-estate developer\'s own records. Use ONLY the passages given. ' +
      'If they do not contain the answer, say so plainly rather than guessing — an invented figure or clause is worse than no answer. ' +
      'Cite the passage number in square brackets when you use one. Keep it short.',
    prompt: `PASSAGES:\n${context}\n\nQUESTION: ${question}`,
    temperature: 0.2,
    maxTokens: 700,
  });
  if (!r.ok) return `I could not reach the AI to answer that. ${r.error}`;
  return r.text;
}


/**
 * Which folder a stored file lives in, so its passages inherit the folder's
 * lock. Without this the AI would quote a restricted contract to anyone.
 */
export async function folderForFile(fileObjectId: string): Promise<string | null> {
  const v = await prisma.documentVersion.findFirst({
    where: { fileId: fileObjectId },
    orderBy: { version: 'desc' },
    select: { document: { select: { folderId: true } } },
  });
  return v?.document?.folderId ?? null;
}
